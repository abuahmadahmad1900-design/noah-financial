#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from flask import Flask, render_template, jsonify
import importlib.util, os

app = Flask(__name__)
BASE = "/data/data/com.termux/files/home/noah_eaglet/"

def load_noah():
    spec = importlib.util.spec_from_file_location("noah_final", BASE + "noah_final.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

# تحميل الملفات الإضافية دفعة واحدة
EXTRA_FILES = [
    "higher_entities_6.py", "entities_boost.py", "entities_boost2.py",
    "selfdev_extra1.py", "selfdev_extra2.py", "selfdev_extra3.py", "selfdev_extra4.py",
    "selfdev_mega1.py", "selfdev_mega2.py", "selfdev_mega3.py",
    "trade_omni_part1.py", "trade_omni_part2.py", "trade_omni_part3.py", "trade_omni_part4.py",
    "trade_omni_essential.py",
    "scientific_platforms_extra1.py", "scientific_platforms_extra2.py",
    "scientific_platforms_extra3.py", "scientific_platforms_extra4.py",
    "islamic_extra1.py", "islamic_extra2.py", "islamic_extra3.py",
    "knowledge_prime_extra1.py", "knowledge_prime_extra2.py",
    "learning_extra_part1.py", "learning_extra_part2.py",
    "final_topup.py"
]

external_lists = {}
for fname in EXTRA_FILES:
    path = BASE + fname
    if os.path.exists(path):
        try:
            mod_name = fname[:-3]
            spec = importlib.util.spec_from_file_location(mod_name, path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            for name in dir(mod):
                if not name.startswith('_'):
                    val = getattr(mod, name)
                    if isinstance(val, list):
                        external_lists[name] = val
        except:
            pass

def get_items(attr):
    """جلب قائمة من نوح أو من الملفات الخارجية"""
    noah = load_noah()
    if attr in external_lists:
        return external_lists[attr]
    if hasattr(noah, attr):
        return getattr(noah, attr)
    return []

def safe_len(obj):
    try:
        return len(obj)
    except:
        return 0

MAPPING = [
    ('الأباطرة', 'emperors'),
    ('العقول', 'all_minds_400'),
    ('الدروع', 'shields'),
    ('محركات الخلق', 'genesis_engines'),
    ('أنظمة الخوارزمية', 'all_imperial_systems'),
    ('الأنظمة المالية', 'financial_systems'),
    ('الأنظمة المحاسبية', 'accounting_systems'),
    ('القطاعات', 'all_sectors'),
    ('المتاجر', 'all_stores'),
    ('قدرات المتاجر', 'all_store_superpowers'),
    ('قدرات العلاقات', 'all_human_relations_powers'),
    ('قدرات التوفير', 'all_financial_optimization_powers'),
    ('أنظمة التوفير', 'all_financial_optimization_systems'),
    ('قدرات الضغط', 'all_compression_powers'),
    ('أنظمة الضغط', 'all_compression_systems'),
    ('قدرات المدفوعات', 'all_payment_powers'),
    ('أنظمة المدفوعات', 'all_payment_systems'),
    ('أنظمة OmniCore', 'all_omnicore_systems'),
    ('قدرات OmniCore', 'omnicore_powers_500'),
    ('أنظمة OmniSovereign', 'all_omnisovereign_systems'),
    ('قدرات OmniSovereign', 'all_omnisovereign_powers'),
    ('أنظمة OmniInfinite', 'all_omniinfinite_systems'),
    ('قدرات OmniInfinite', 'all_omniinfinite_powers'),
    ('أنظمة KnowledgePrime', 'all_knowledge_prime_systems'),
    ('قدرات KnowledgePrime', 'all_knowledge_prime_powers'),
    ('المؤسسات التعليمية', 'all_educational_institutions'),
    ('المراجع الشرعية', 'all_islamic_references'),
    ('المكونات الشرعية', 'all_islamic_complete'),
    ('أنظمة التعلم', 'all_learning_systems'),
    ('قدرات التعلم', 'all_learning_powers'),
    ('المكونات العلمية', 'all_scientific_tech'),
    ('الكيانات العليا', 'all_higher_entities'),
    ('تقوية الكيانات', 'all_entities_boost'),
    ('أنظمة SelfDevPrime', 'all_selfdev_systems'),
    ('قدرات SelfDevPrime', 'selfdev_prime_powers'),
    ('أنظمة SelfDevPrime Mega', 'all_selfdev_mega_systems'),
    ('قدرات SelfDevPrime Mega', 'all_selfdev_mega_powers'),
    ('أنظمة TradeOmniPrime', 'all_trade_omni'),
    ('قدرات TradeOmniPrime', 'all_trade_essential'),
    ('المنصات العلمية الأصلية', 'scientific_platforms_200'),
    ('المنصات العلمية الإضافية', 'all_scientific_platforms_extra'),
    ('عناصر الروح', 'soul_elements'),
    ('فئات القدرات', 'capability_categories'),
    ('إضافات الوصول إلى 27,000', 'final_topup_items'),
]

@app.route('/')
def index():
    noah = load_noah()
    emperors = list(noah.emperors) if hasattr(noah, 'emperors') else []
    stats = {}
    for label, attr in MAPPING:
        items = get_items(attr)
        stats[label] = safe_len(items)
    total = sum(stats.values())
    stats['الإجمالي'] = total
    stats['total'] = total
    return render_template('index.html', stats=stats, emperors=emperors)

@app.route('/minds')
def minds():
    items = get_items('all_minds_400')
    return render_template('minds.html', minds=items, count=len(items))

@app.route('/browse')
def browse():
    categories = []
    for label, attr in MAPPING:
        items = get_items(attr)
        categories.append({'label': label, 'attr': attr, 'count': safe_len(items)})
    return render_template('browse.html', categories=categories)

@app.route('/all')
def all_items():
    all_data = []
    for label, attr in MAPPING:
        items = get_items(attr)
        for item in items:
            all_data.append((item, label))
    return render_template('all.html', all_data=all_data, count=len(all_data))

@app.route('/category/<attr>')
def category(attr):
    items = get_items(attr)
    return render_template('category.html', attr=attr, items=items, count=len(items))

@app.route('/api/stats')
def api_stats():
    stats = {}
    for label, attr in MAPPING:
        stats[label] = safe_len(get_items(attr))
    total = sum(stats.values())
    stats['total'] = total
    return jsonify(stats)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
