from flask import Flask, render_template_string, request, session, redirect
import sqlite3

app = Flask(__name__)
app.secret_key = 'noah2026'
DB = 'noah.db'

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE,
        password TEXT
    )''')
    c.execute("INSERT OR IGNORE INTO users (username, password) VALUES ('admin', '123456')")
    conn.commit()
    conn.close()

init_db()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect(DB)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user'] = username
            return redirect('/')
        return 'خطأ في الدخول'
    return '''
    <form method="POST">
        <input type="text" name="username" placeholder="المستخدم" required>
        <input type="password" name="password" placeholder="كلمة المرور" required>
        <button>دخول</button>
    </form>'''

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/login')

@app.route('/')
def home():
    if 'user' not in session:
        return redirect('/login')
    return redirect('/legendary')

PAGE_STYLE = '''
<style>
    body { font-family: Tahoma; background: #111; color: #eee; padding: 20px; direction: rtl; }
    a { color: #4af; text-decoration: none; margin: 5px; }
    a:hover { color: #0ff; }
    input, select, button { padding: 8px; margin: 5px; background: #222; color: #eee; border: 1px solid #555; border-radius: 5px; }
    button { background: #4af; color: #000; cursor: pointer; }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; }
    th, td { border: 1px solid #444; padding: 8px; text-align: center; }
    th { background: #333; color: #4af; }
    .container { background: #1a1a1a; padding: 20px; border-radius: 10px; }
    .nav { background: #1a1a3e; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
</style>
'''

# لوحة تحكم بسيطة
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM accounts")
    accounts = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM customers")
    customers = c.fetchone()[0]
    conn.close()
    content = f'''
    <h2>📊 لوحة التحكم</h2>
    <p>الحسابات: {accounts}</p>
    <p>العملاء: {customers}</p>
    '''
    return PAGE_STYLE + content

# إضافة الجداول
def add_tables():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY,
        name TEXT,
        type TEXT,
        balance REAL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY,
        name TEXT,
        phone TEXT,
        balance REAL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY,
        name TEXT,
        phone TEXT,
        balance REAL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY,
        customer_id INTEGER,
        amount REAL,
        date TEXT
    );
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY,
        name TEXT,
        price REAL,
        stock INTEGER
    );
    ''')
    conn.commit()
    conn.close()

add_tables()

# واجهة الحسابات
@app.route('/accounts', methods=['GET', 'POST'])
def accounts():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        type_acc = request.form['type']
        c.execute("INSERT INTO accounts (name, type) VALUES (?,?)", (name, type_acc))
        conn.commit()
    c.execute("SELECT * FROM accounts")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/dashboard">🏠 الرئيسية</a>
        <a href="/accounts">📚 الحسابات</a>
        <a href="/customers">👥 العملاء</a>
        <a href="/suppliers">📦 الموردون</a>
        <a href="/invoices">🧾 الفواتير</a>
        <a href="/products">📦 المنتجات</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>📚 الحسابات</h2>
    <form method="POST">
        <input name="name" placeholder="اسم الحساب" required>
        <select name="type">
            <option>أصول</option>
            <option>خصوم</option>
            <option>حقوق ملكية</option>
            <option>إيرادات</option>
            <option>مصاريف</option>
        </select>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الاسم</th><th>النوع</th><th>الرصيد</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# واجهة العملاء
@app.route('/customers', methods=['GET', 'POST'])
def customers():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        c.execute("INSERT INTO customers (name, phone) VALUES (?,?)", (name, phone))
        conn.commit()
    c.execute("SELECT * FROM customers")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/dashboard">🏠 الرئيسية</a>
        <a href="/accounts">📚 الحسابات</a>
        <a href="/customers">👥 العملاء</a>
        <a href="/suppliers">📦 الموردون</a>
        <a href="/invoices">🧾 الفواتير</a>
        <a href="/products">📦 المنتجات</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>👥 العملاء</h2>
    <form method="POST">
        <input name="name" placeholder="اسم العميل" required>
        <input name="phone" placeholder="الهاتف">
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الاسم</th><th>الهاتف</th><th>الرصيد</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# واجهة المنتجات
@app.route('/products', methods=['GET', 'POST'])
def products():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        price = request.form['price']
        stock = request.form['stock']
        c.execute("INSERT INTO products (name, price, stock) VALUES (?,?,?)",
                  (name, price, stock))
        conn.commit()
    c.execute("SELECT * FROM products")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/dashboard">🏠 الرئيسية</a>
        <a href="/accounts">📚 الحسابات</a>
        <a href="/customers">👥 العملاء</a>
        <a href="/suppliers">📦 الموردون</a>
        <a href="/invoices">🧾 الفواتير</a>
        <a href="/products">📦 المنتجات</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>📦 المنتجات</h2>
    <form method="POST">
        <input name="name" placeholder="اسم المنتج" required>
        <input name="price" placeholder="السعر" required>
        <input name="stock" placeholder="المخزون" required>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الاسم</th><th>السعر</th><th>المخزون</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# تشغيل التطبيق

# ========== لوحة التحكم الأسطورية ==========
@app.route('/legendary')
def legendary():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM accounts")
    accounts = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM customers")
    customers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM suppliers")
    suppliers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM invoices")
    invoices = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM products")
    products = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    revenue = c.fetchone()[0]
    conn.close()

    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>نوح - لوحة القيادة الأسطورية</title>
        <style>
            body {{
                font-family: Tahoma;
                background: #0a0a2e;
                color: #fff;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 20px;
                margin: 0;
            }}
            .container {{
                width: 100%;
                max-width: 1100px;
                background: rgba(20,20,50,0.8);
                border-radius: 30px;
                padding: 30px;
                box-shadow: 0 25px 60px rgba(0,0,0,0.8), 0 0 30px rgba(255,215,0,0.3);
                border: 1px solid rgba(255,215,0,0.4);
                animation: glow 3s ease-in-out infinite alternate;
            }}
            @keyframes glow {{
                from {{ box-shadow: 0 25px 60px rgba(0,0,0,0.8), 0 0 20px rgba(255,215,0,0.2); }}
                to {{ box-shadow: 0 25px 60px rgba(0,0,0,0.8), 0 0 50px rgba(255,215,0,0.6); }}
            }}
            h1 {{
                text-align: center;
                font-size: 3rem;
                background: linear-gradient(45deg, #FFD700, #FF8C00, #FFD700);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                margin-bottom: 10px;
            }}
            .subtitle {{
                text-align: center;
                color: #aaa;
                margin-bottom: 40px;
                font-size: 1.2rem;
            }}
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                gap: 20px;
                margin-bottom: 40px;
            }}
            .stat-card {{
                background: linear-gradient(145deg, #1a1a3e, #0d0d24);
                border-radius: 20px;
                padding: 25px;
                text-align: center;
                border: 1px solid rgba(255,255,255,0.1);
                transition: all 0.3s;
            }}
            .stat-card:hover {{
                transform: translateY(-10px);
                border-color: #00c8ff;
                box-shadow: 0 15px 30px rgba(0,200,255,0.3);
            }}
            .stat-card .icon {{
                font-size: 3rem;
                margin-bottom: 10px;
            }}
            .stat-card .value {{
                font-size: 2.5rem;
                font-weight: bold;
                color: #fff;
            }}
            .stat-card .label {{
                color: #888;
                font-size: 0.9rem;
                margin-top: 5px;
            }}
            .highlight {{
                background: linear-gradient(145deg, #2a2a4e, #1a1a3e);
                border-radius: 20px;
                padding: 30px;
                text-align: center;
                margin-bottom: 30px;
                border: 1px solid rgba(255,215,0,0.3);
            }}
            .highlight h2 {{
                color: #FFD700;
                font-size: 1.5rem;
                margin-bottom: 15px;
            }}
            .highlight .amount {{
                font-size: 3rem;
                font-weight: bold;
                background: linear-gradient(45deg, #FFD700, #FF8C00);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
            }}
            .nav-links {{
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                justify-content: center;
                margin-top: 20px;
            }}
            .nav-links a {{
                background: linear-gradient(145deg, #222244, #111133);
                color: #fff;
                padding: 12px 25px;
                border-radius: 30px;
                text-decoration: none;
                font-size: 0.9rem;
                border: 1px solid rgba(255,255,255,0.2);
                transition: all 0.3s;
            }}
            .nav-links a:hover {{
                background: #00c8ff;
                color: #000;
                transform: scale(1.1);
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>نوح - لوحة القيادة الأسطورية</h1>
            <p class="subtitle">النظام المالي الأقوى في العالم</p>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon">📚</div>
                    <div class="value">{accounts}</div>
                    <div class="label">الحسابات</div>
                </div>
                <div class="stat-card">
                    <div class="icon">👥</div>
                    <div class="value">{customers}</div>
                    <div class="label">العملاء</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📦</div>
                    <div class="value">{suppliers}</div>
                    <div class="label">الموردون</div>
                </div>
                <div class="stat-card">
                    <div class="icon">🧾</div>
                    <div class="value">{invoices}</div>
                    <div class="label">الفواتير</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📦</div>
                    <div class="value">{products}</div>
                    <div class="label">المنتجات</div>
                </div>
            </div>

            <div class="highlight">
                <h2>💰 إجمالي الإيرادات</h2>
                <div class="amount">{revenue}</div>
            </div>

            <div class="nav-links">
                <a href="/accounts">📚 الحسابات</a>
                <a href="/customers">👥 العملاء</a>
                <a href="/suppliers">📦 الموردون</a>
                <a href="/invoices">🧾 الفواتير</a>
                <a href="/products">📦 المنتجات</a>
                <a href="/logout">🚪 خروج</a>
            </div>
        </div>
    </body>
    </html>
    '''


# ========== لوحة التحكم الخيالية ==========
@app.route('/legendary_v2')
def legendary_v2():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM accounts")
    accounts = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM customers")
    customers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM suppliers")
    suppliers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM invoices")
    invoices = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM products")
    products = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    revenue = c.fetchone()[0]
    conn.close()

    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>🦅 نوح - لوحة القيادة الخيالية</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: Tahoma, sans-serif;
                background: #0a0a1a;
                color: #fff;
                min-height: 100vh;
                overflow-x: hidden;
                position: relative;
            }}
            /* جزيئات متحركة */
            .particle {{
                position: fixed;
                border-radius: 50%;
                background: rgba(0,200,255,0.6);
                pointer-events: none;
                animation: float-particle linear infinite;
            }}
            @keyframes float-particle {{
                0% {{ transform: translateY(100vh) scale(0); opacity: 0; }}
                10% {{ opacity: 1; }}
                90% {{ opacity: 1; }}
                100% {{ transform: translateY(-10vh) scale(1); opacity: 0; }}
            }}
            .main-container {{
                position: relative;
                z-index: 2;
                max-width: 1200px;
                margin: 0 auto;
                padding: 30px 20px;
            }}
            .header {{
                text-align: center;
                margin-bottom: 50px;
            }}
            .header h1 {{
                font-size: 3.5rem;
                font-weight: 900;
                background: linear-gradient(45deg, #FFD700, #FF8C00, #FFD700, #FF8C00);
                background-size: 300% 300%;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: gradient-shift 3s ease infinite, pulse-glow 2s ease-in-out infinite alternate;
                margin-bottom: 15px;
            }}
            @keyframes gradient-shift {{
                0% {{ background-position: 0% 50%; }}
                50% {{ background-position: 100% 50%; }}
                100% {{ background-position: 0% 50%; }}
            }}
            @keyframes pulse-glow {{
                from {{ text-shadow: 0 0 10px #FFD700, 0 0 20px #FFA500; }}
                to {{ text-shadow: 0 0 30px #FFD700, 0 0 60px #FF8C00; }}
            }}
            .header .subtitle {{
                color: #ccc;
                font-size: 1.2rem;
                letter-spacing: 2px;
            }}
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 25px;
                margin-bottom: 40px;
            }}
            .stat-card {{
                background: linear-gradient(145deg, rgba(30,30,70,0.9), rgba(15,15,40,0.9));
                border-radius: 25px;
                padding: 30px 20px;
                text-align: center;
                border: 1px solid rgba(255,255,255,0.15);
                box-shadow: 0 10px 40px rgba(0,0,0,0.5), 0 0 20px rgba(0,200,255,0.1) inset;
                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                cursor: pointer;
                position: relative;
                overflow: hidden;
            }}
            .stat-card::before {{
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: conic-gradient(from 0deg, transparent, rgba(0,200,255,0.15), transparent, rgba(255,215,0,0.15), transparent);
                animation: rotate-border 4s linear infinite;
            }}
            @keyframes rotate-border {{
                100% {{ transform: rotate(360deg); }}
            }}
            .stat-card:hover {{
                transform: translateY(-15px) scale(1.05);
                box-shadow: 0 20px 50px rgba(0,200,255,0.3), 0 0 30px rgba(0,200,255,0.4) inset;
                border-color: #00c8ff;
            }}
            .stat-card .icon {{
                font-size: 3.5rem;
                margin-bottom: 15px;
                position: relative;
                z-index: 1;
                animation: bounce-icon 2s ease-in-out infinite;
            }}
            @keyframes bounce-icon {{
                0%, 100% {{ transform: translateY(0); }}
                50% {{ transform: translateY(-10px); }}
            }}
            .stat-card .value {{
                font-size: 2.8rem;
                font-weight: 900;
                color: #fff;
                text-shadow: 0 0 20px rgba(0,200,255,0.7);
                position: relative;
                z-index: 1;
            }}
            .stat-card .label {{
                color: #aaa;
                font-size: 1rem;
                margin-top: 10px;
                position: relative;
                z-index: 1;
            }}
            .revenue-section {{
                background: linear-gradient(145deg, rgba(40,40,90,0.95), rgba(20,20,50,0.95));
                border-radius: 30px;
                padding: 40px;
                text-align: center;
                margin-bottom: 40px;
                border: 1px solid rgba(255,215,0,0.4);
                box-shadow: 0 15px 40px rgba(0,0,0,0.6), 0 0 30px rgba(255,215,0,0.2);
                position: relative;
                overflow: hidden;
            }}
            .revenue-section::before {{
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: radial-gradient(circle, rgba(255,215,0,0.1), transparent 70%);
                animation: pulse-bg 3s ease-in-out infinite;
            }}
            @keyframes pulse-bg {{
                0%, 100% {{ transform: scale(1); opacity: 0.5; }}
                50% {{ transform: scale(1.2); opacity: 1; }}
            }}
            .revenue-section h2 {{
                color: #FFD700;
                font-size: 1.8rem;
                margin-bottom: 20px;
                position: relative;
                z-index: 1;
            }}
            .revenue-section .amount {{
                font-size: 4rem;
                font-weight: 900;
                background: linear-gradient(45deg, #FFD700, #FF8C00, #FFD700);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: gradient-shift 2s ease infinite;
                position: relative;
                z-index: 1;
            }}
            .quick-actions {{
                display: flex;
                flex-wrap: wrap;
                gap: 15px;
                justify-content: center;
                margin-top: 30px;
            }}
            .quick-actions a {{
                background: linear-gradient(145deg, #222244, #111133);
                color: #fff;
                padding: 15px 30px;
                border-radius: 50px;
                text-decoration: none;
                font-size: 1rem;
                border: 1px solid rgba(255,255,255,0.25);
                transition: all 0.4s;
                position: relative;
                overflow: hidden;
            }}
            .quick-actions a::before {{
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                transition: left 0.5s;
            }}
            .quick-actions a:hover::before {{
                left: 100%;
            }}
            .quick-actions a:hover {{
                background: #00c8ff;
                color: #000;
                transform: scale(1.1);
                box-shadow: 0 0 30px rgba(0,200,255,0.6);
            }}
        </style>
    </head>
    <body>
        <div class="main-container">
            <div class="header">
                <h1>🦅 نوح - لوحة القيادة الخيالية</h1>
                <p class="subtitle">النظام المالي الأسطوري الذي لا يُهزم</p>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon">📚</div>
                    <div class="value" data-target="{accounts}">0</div>
                    <div class="label">الحسابات</div>
                </div>
                <div class="stat-card">
                    <div class="icon">👥</div>
                    <div class="value" data-target="{customers}">0</div>
                    <div class="label">العملاء</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📦</div>
                    <div class="value" data-target="{suppliers}">0</div>
                    <div class="label">الموردون</div>
                </div>
                <div class="stat-card">
                    <div class="icon">🧾</div>
                    <div class="value" data-target="{invoices}">0</div>
                    <div class="label">الفواتير</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📦</div>
                    <div class="value" data-target="{products}">0</div>
                    <div class="label">المنتجات</div>
                </div>
            </div>

            <div class="revenue-section">
                <h2>💰 إجمالي الإيرادات</h2>
                <div class="amount" id="revenue-counter">{revenue}</div>
            </div>

            <div class="quick-actions">
                <a href="/accounts">📚 الحسابات</a>
                <a href="/customers">👥 العملاء</a>
                <a href="/suppliers">📦 الموردون</a>
                <a href="/invoices">🧾 الفواتير</a>
                <a href="/products">📦 المنتجات</a>
                <a href="/logout">🚪 خروج</a>
            </div>
        </div>

        <script>
            // جزيئات متحركة
            for (let i = 0; i < 50; i++) {{
                const particle = document.createElement('div');
                particle.classList.add('particle');
                particle.style.left = Math.random() * 100 + '%';
                particle.style.width = Math.random() * 5 + 2 + 'px';
                particle.style.height = particle.style.width;
                particle.style.animationDuration = Math.random() * 10 + 5 + 's';
                particle.style.animationDelay = Math.random() * 10 + 's';
                document.body.appendChild(particle);
            }}

            // عدادات متحركة
            document.querySelectorAll('.value').forEach(el => {{
                const target = parseInt(el.getAttribute('data-target'));
                let current = 0;
                const step = Math.max(1, Math.floor(target / 50));
                const interval = setInterval(() => {{
                    current += step;
                    if (current >= target) {{
                        el.textContent = target;
                        clearInterval(interval);
                    }} else {{
                        el.textContent = current;
                    }}
                }}, 30);
            }});

            // عداد الإيرادات
            const revEl = document.getElementById('revenue-counter');
            const revTarget = parseInt(revEl.textContent);
            let revCurrent = 0;
            const revInterval = setInterval(() => {{
                revCurrent += Math.max(1, Math.floor(revTarget / 100));
                if (revCurrent >= revTarget) {{
                    revEl.textContent = revTarget;
                    clearInterval(revInterval);
                }} else {{
                    revEl.textContent = revCurrent;
                }}
            }}, 20);
        </script>
    </body>
    </html>
    '''


# ========== لوحة التحكم الساحرة ==========
@app.route('/magical')
def magical():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM accounts")
    accounts = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM customers")
    customers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM suppliers")
    suppliers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM invoices")
    invoices = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM products")
    products = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    revenue = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(stock),0) FROM products")
    total_stock = c.fetchone()[0]
    conn.close()

    # حساب نسبة المخزون (افتراض أن الحد الأقصى 1000)
    stock_percent = min(total_stock / 10, 100) if total_stock > 0 else 0

    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>🦅 نوح - السحر المالي</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: Tahoma, sans-serif;
                background: #000011;
                color: #fff;
                min-height: 100vh;
                overflow-x: hidden;
                position: relative;
                cursor: default;
            }}
            /* نجوم متحركة */
            .star {{
                position: fixed;
                border-radius: 50%;
                background: #fff;
                pointer-events: none;
                animation: twinkle ease-in-out infinite;
            }}
            @keyframes twinkle {{
                0%, 100% {{ opacity: 0.3; transform: scale(1); }}
                50% {{ opacity: 1; transform: scale(1.5); }}
            }}
            /* مجرة دوارة */
            .galaxy {{
                position: fixed;
                top: 50%;
                left: 50%;
                width: 800px;
                height: 800px;
                background: radial-gradient(circle, rgba(100,50,200,0.15), transparent 60%);
                border-radius: 50%;
                pointer-events: none;
                animation: rotate-galaxy 30s linear infinite;
                z-index: 0;
            }}
            @keyframes rotate-galaxy {{
                from {{ transform: translate(-50%, -50%) rotate(0deg); }}
                to {{ transform: translate(-50%, -50%) rotate(360deg); }}
            }}
            .main-container {{
                position: relative;
                z-index: 2;
                max-width: 1200px;
                margin: 0 auto;
                padding: 30px 20px;
            }}
            /* ساعة حية */
            .clock {{
                position: absolute;
                top: 20px;
                left: 20px;
                color: #FFD700;
                font-size: 1.2rem;
                text-shadow: 0 0 10px rgba(255,215,0,0.5);
                z-index: 10;
            }}
            .header {{
                text-align: center;
                margin-bottom: 50px;
            }}
            .header h1 {{
                font-size: 3.5rem;
                font-weight: 900;
                background: linear-gradient(45deg, #FFD700, #FF8C00, #FFD700, #FF8C00);
                background-size: 300% 300%;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: gradient-shift 3s ease infinite, pulse-glow 2s ease-in-out infinite alternate;
                margin-bottom: 15px;
                cursor: default;
            }}
            @keyframes gradient-shift {{
                0% {{ background-position: 0% 50%; }}
                50% {{ background-position: 100% 50%; }}
                100% {{ background-position: 0% 50%; }}
            }}
            @keyframes pulse-glow {{
                from {{ text-shadow: 0 0 10px #FFD700, 0 0 20px #FFA500; }}
                to {{ text-shadow: 0 0 30px #FFD700, 0 0 60px #FF8C00; }}
            }}
            .header .subtitle {{
                color: #ccc;
                font-size: 1.2rem;
                letter-spacing: 2px;
                animation: fade-in-out 3s ease-in-out infinite;
            }}
            @keyframes fade-in-out {{
                0%, 100% {{ opacity: 0.6; }}
                50% {{ opacity: 1; }}
            }}
            /* بطاقات ثلاثية الأبعاد */
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 25px;
                margin-bottom: 40px;
                perspective: 1000px;
            }}
            .stat-card {{
                background: linear-gradient(145deg, rgba(30,30,70,0.9), rgba(15,15,40,0.9));
                border-radius: 25px;
                padding: 30px 20px;
                text-align: center;
                border: 1px solid rgba(255,255,255,0.15);
                box-shadow: 0 10px 40px rgba(0,0,0,0.5), 0 0 20px rgba(0,200,255,0.1) inset;
                transition: transform 0.1s ease-out;
                cursor: pointer;
                position: relative;
                overflow: hidden;
                transform-style: preserve-3d;
            }}
            .stat-card::before {{
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: conic-gradient(from 0deg, transparent, rgba(0,200,255,0.2), transparent, rgba(255,215,0,0.2), transparent);
                animation: rotate-border 4s linear infinite;
            }}
            @keyframes rotate-border {{
                100% {{ transform: rotate(360deg); }}
            }}
            .stat-card .icon {{
                font-size: 3.5rem;
                margin-bottom: 15px;
                position: relative;
                z-index: 1;
                animation: bounce-icon 2s ease-in-out infinite;
                filter: drop-shadow(0 0 10px rgba(0,200,255,0.5));
            }}
            @keyframes bounce-icon {{
                0%, 100% {{ transform: translateY(0); }}
                50% {{ transform: translateY(-10px); }}
            }}
            .stat-card .value {{
                font-size: 2.8rem;
                font-weight: 900;
                color: #fff;
                text-shadow: 0 0 20px rgba(0,200,255,0.7);
                position: relative;
                z-index: 1;
            }}
            .stat-card .label {{
                color: #aaa;
                font-size: 1rem;
                margin-top: 10px;
                position: relative;
                z-index: 1;
            }}
            /* قسم الإيرادات */
            .revenue-section {{
                background: linear-gradient(145deg, rgba(40,40,90,0.95), rgba(20,20,50,0.95));
                border-radius: 30px;
                padding: 40px;
                text-align: center;
                margin-bottom: 30px;
                border: 1px solid rgba(255,215,0,0.4);
                box-shadow: 0 15px 40px rgba(0,0,0,0.6), 0 0 30px rgba(255,215,0,0.2);
                position: relative;
                overflow: hidden;
            }}
            .revenue-section::before {{
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: radial-gradient(circle, rgba(255,215,0,0.15), transparent 70%);
                animation: pulse-bg 3s ease-in-out infinite;
            }}
            @keyframes pulse-bg {{
                0%, 100% {{ transform: scale(1); opacity: 0.5; }}
                50% {{ transform: scale(1.3); opacity: 1; }}
            }}
            .revenue-section h2 {{
                color: #FFD700;
                font-size: 1.8rem;
                margin-bottom: 20px;
                position: relative;
                z-index: 1;
            }}
            .revenue-section .amount {{
                font-size: 4rem;
                font-weight: 900;
                background: linear-gradient(45deg, #FFD700, #FF8C00, #FFD700);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: gradient-shift 2s ease infinite;
                position: relative;
                z-index: 1;
            }}
            /* شريط التقدم */
            .progress-container {{
                margin: 30px 0;
                background: rgba(0,0,0,0.3);
                border-radius: 20px;
                padding: 20px;
            }}
            .progress-bar {{
                width: 100%;
                height: 30px;
                background: #1a1a3e;
                border-radius: 15px;
                overflow: hidden;
                position: relative;
            }}
            .progress-fill {{
                height: 100%;
                background: linear-gradient(90deg, #00c8ff, #FFD700);
                border-radius: 15px;
                animation: progress-shine 2s ease-in-out infinite;
                transition: width 1s ease-out;
            }}
            @keyframes progress-shine {{
                0% {{ filter: brightness(1); }}
                50% {{ filter: brightness(1.5); }}
                100% {{ filter: brightness(1); }}
            }}
            .progress-label {{
                color: #ccc;
                margin-top: 10px;
                text-align: center;
            }}
            /* أزرار سريعة */
            .quick-actions {{
                display: flex;
                flex-wrap: wrap;
                gap: 15px;
                justify-content: center;
                margin-top: 30px;
            }}
            .quick-actions a {{
                background: linear-gradient(145deg, #222244, #111133);
                color: #fff;
                padding: 15px 30px;
                border-radius: 50px;
                text-decoration: none;
                font-size: 1rem;
                border: 1px solid rgba(255,255,255,0.25);
                transition: all 0.4s;
                position: relative;
                overflow: hidden;
            }}
            .quick-actions a::before {{
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
                transition: left 0.5s;
            }}
            .quick-actions a:hover::before {{
                left: 100%;
            }}
            .quick-actions a:hover {{
                background: #00c8ff;
                color: #000;
                transform: scale(1.1);
                box-shadow: 0 0 30px rgba(0,200,255,0.6);
            }}
        </style>
    </head>
    <body>
        <div class="clock" id="clock"></div>
        <div class="galaxy"></div>

        <div class="main-container">
            <div class="header">
                <h1>🦅 نوح - السحر المالي</h1>
                <p class="subtitle">حيث تلتقي القوة بالذكاء والبراعة</p>
            </div>

            <div class="stats-grid" id="stats-grid">
                <div class="stat-card" data-tilt>
                    <div class="icon">📚</div>
                    <div class="value" data-target="{accounts}">0</div>
                    <div class="label">الحسابات</div>
                </div>
                <div class="stat-card" data-tilt>
                    <div class="icon">👥</div>
                    <div class="value" data-target="{customers}">0</div>
                    <div class="label">العملاء</div>
                </div>
                <div class="stat-card" data-tilt>
                    <div class="icon">📦</div>
                    <div class="value" data-target="{suppliers}">0</div>
                    <div class="label">الموردون</div>
                </div>
                <div class="stat-card" data-tilt>
                    <div class="icon">🧾</div>
                    <div class="value" data-target="{invoices}">0</div>
                    <div class="label">الفواتير</div>
                </div>
                <div class="stat-card" data-tilt>
                    <div class="icon">📦</div>
                    <div class="value" data-target="{products}">0</div>
                    <div class="label">المنتجات</div>
                </div>
            </div>

            <div class="revenue-section">
                <h2>💰 إجمالي الإيرادات</h2>
                <div class="amount" id="revenue-counter">{revenue}</div>
            </div>

            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="stock-bar" style="width: 0%;"></div>
                </div>
                <div class="progress-label">📊 مستوى المخزون: <span id="stock-percent">0%</span></div>
            </div>

            <div class="quick-actions">
                <a href="/accounts">📚 الحسابات</a>
                <a href="/customers">👥 العملاء</a>
                <a href="/suppliers">📦 الموردون</a>
                <a href="/invoices">🧾 الفواتير</a>
                <a href="/products">📦 المنتجات</a>
                <a href="/logout">🚪 خروج</a>
            </div>
        </div>

        <script>
            // ساعة حية
            function updateClock() {{
                const now = new Date();
                const time = now.toLocaleTimeString('ar');
                const date = now.toLocaleDateString('ar', {{ weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }});
                document.getElementById('clock').innerHTML = date + ' - ' + time;
            }}
            updateClock();
            setInterval(updateClock, 1000);

            // نجوم متلألئة
            for (let i = 0; i < 100; i++) {{
                const star = document.createElement('div');
                star.classList.add('star');
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.width = Math.random() * 3 + 1 + 'px';
                star.style.height = star.style.width;
                star.style.animationDuration = Math.random() * 3 + 1 + 's';
                star.style.animationDelay = Math.random() * 5 + 's';
                document.body.appendChild(star);
            }}

            // عدادات متحركة
            document.querySelectorAll('.value').forEach(el => {{
                const target = parseInt(el.getAttribute('data-target'));
                let current = 0;
                const step = Math.max(1, Math.floor(target / 60));
                const interval = setInterval(() => {{
                    current += step;
                    if (current >= target) {{
                        el.textContent = target;
                        clearInterval(interval);
                    }} else {{
                        el.textContent = current;
                    }}
                }}, 25);
            }});

            // عداد الإيرادات
            const revEl = document.getElementById('revenue-counter');
            const revTarget = parseInt(revEl.textContent);
            let revCurrent = 0;
            const revInterval = setInterval(() => {{
                revCurrent += Math.max(1, Math.floor(revTarget / 120));
                if (revCurrent >= revTarget) {{
                    revEl.textContent = revTarget;
                    clearInterval(revInterval);
                }} else {{
                    revEl.textContent = revCurrent;
                }}
            }}, 15);

            // شريط المخزون
            setTimeout(() => {{
                document.getElementById('stock-bar').style.width = '{stock_percent}%';
                document.getElementById('stock-percent').textContent = '{stock_percent:.1f}%';
            }}, 500);

            // تأثير ثلاثي الأبعاد عند تحريك الماوس
            document.querySelectorAll('[data-tilt]').forEach(card => {{
                card.addEventListener('mousemove', (e) => {{
                    const rect = card.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    const centerX = rect.width / 2;
                    const centerY = rect.height / 2;
                    const rotateX = (y - centerY) / 20;
                    const rotateY = (centerX - x) / 20;
                    card.style.transform = `perspective(1000px) rotateX(${{rotateX}}deg) rotateY(${{rotateY}}deg) translateY(-10px)`;
                }});
                card.addEventListener('mouseleave', () => {{
                    card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0)';
                }});
            }});
        </script>
    </body>
    </html>
    '''


# ========== إضافة الجداول المتقدمة ==========
def add_advanced_tables():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS bank_moves (
        id INTEGER PRIMARY KEY,
        date TEXT,
        desc TEXT,
        amount REAL,
        reconciled INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS zakat (
        id INTEGER PRIMARY KEY,
        amount REAL,
        date TEXT,
        paid INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS debts (
        id INTEGER PRIMARY KEY,
        name TEXT,
        amount REAL,
        type TEXT
    );
    CREATE TABLE IF NOT EXISTS assets (
        id INTEGER PRIMARY KEY,
        name TEXT,
        value REAL,
        depreciation REAL
    );
    CREATE TABLE IF NOT EXISTS budgets (
        id INTEGER PRIMARY KEY,
        name TEXT,
        amount REAL
    );
    CREATE TABLE IF NOT EXISTS currencies (
        id INTEGER PRIMARY KEY,
        code TEXT,
        rate REAL
    );
    CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY,
        name TEXT,
        budget REAL,
        start_date TEXT,
        end_date TEXT,
        status TEXT DEFAULT 'نشط'
    );
    CREATE TABLE IF NOT EXISTS contracts (
        id INTEGER PRIMARY KEY,
        title TEXT,
        party TEXT,
        amount REAL,
        date TEXT,
        status TEXT DEFAULT 'ساري'
    );
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY,
        sender TEXT,
        receiver TEXT,
        subject TEXT,
        body TEXT,
        date TEXT,
        read INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY,
        action TEXT,
        date TEXT
    );
    ''')
    conn.commit()
    conn.close()

add_advanced_tables()
print("✅ تم إضافة الجداول المتقدمة")

# ========== تسجيل التدقيق ==========
def log_action(action):
    try:
        conn = sqlite3.connect(DB)
        c = conn.cursor()
        from datetime import datetime
        c.execute("INSERT INTO audit_log (action, date) VALUES (?,?)",
                  (action, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        conn.commit()
        conn.close()
    except:
        pass

# ========== دالة التنبيهات الذكية ==========
def create_alerts():
    from datetime import datetime
    try:
        conn = sqlite3.connect(DB)
        c = conn.cursor()
        # إنشاء جدول التنبيهات إذا لم يوجد
        c.execute('''CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY,
            message TEXT,
            type TEXT,
            date TEXT
        )''')
        # فواتير غير مدفوعة
        c.execute("SELECT COUNT(*) FROM invoices")
        unpaid = c.fetchone()[0]
        if unpaid > 0:
            c.execute("INSERT INTO alerts (message, type, date) VALUES (?, 'warning', ?)",
                      (f"لديك {unpaid} فاتورة", datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        # مخزون منخفض
        c.execute("SELECT COUNT(*) FROM products WHERE stock < 5")
        low_stock = c.fetchone()[0]
        if low_stock > 0:
            c.execute("INSERT INTO alerts (message, type, date) VALUES (?, 'danger', ?)",
                      (f"{low_stock} منتج مخزونه منخفض", datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        conn.commit()
        conn.close()
    except:
        pass

# ========== واجهة البنك ==========
@app.route('/bank', methods=['GET', 'POST'])
def bank():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        date = request.form['date']
        desc = request.form['desc']
        amount = request.form['amount']
        c.execute("INSERT INTO bank_moves (date, desc, amount) VALUES (?,?,?)",
                  (date, desc, amount))
        conn.commit()
        log_action(f"حركة بنكية: {desc}")
    c.execute("SELECT * FROM bank_moves ORDER BY id DESC")
    rows = c.fetchall()
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves")
    balance = c.fetchone()[0]
    conn.close()
    content = f'''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/accounts">📚 الحسابات</a>
        <a href="/customers">👥 العملاء</a>
        <a href="/suppliers">📦 الموردون</a>
        <a href="/invoices">🧾 الفواتير</a>
        <a href="/products">📦 المنتجات</a>
        <a href="/bank">🏦 البنك</a>
        <a href="/zakat">🕌 الزكاة</a>
        <a href="/debts">💳 الديون</a>
        <a href="/budgets">📋 الميزانيات</a>
        <a href="/projects">📁 المشاريع</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>🏦 البنك</h2>
    <p style="font-size:1.5rem;color:#FFD700;">الرصيد الحالي: {balance}</p>
    <form method="POST">
        <input name="date" type="date" required>
        <input name="desc" placeholder="الوصف" required>
        <input name="amount" placeholder="المبلغ" required>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>التاريخ</th><th>الوصف</th><th>المبلغ</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة الزكاة ==========
@app.route('/zakat', methods=['GET', 'POST'])
def zakat():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        amount = request.form['amount']
        date = request.form['date']
        c.execute("INSERT INTO zakat (amount, date) VALUES (?,?)", (amount, date))
        conn.commit()
        log_action(f"تسجيل زكاة: {amount}")
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount > 0")
    total_money = c.fetchone()[0]
    nisab = 85 * 60
    zakat_due = total_money * 0.025 if total_money >= nisab else 0
    c.execute("SELECT * FROM zakat")
    rows = c.fetchall()
    conn.close()
    content = f'''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/accounts">📚 الحسابات</a>
        <a href="/bank">🏦 البنك</a>
        <a href="/zakat">🕌 الزكاة</a>
        <a href="/debts">💳 الديون</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>🕌 الزكاة</h2>
    <div style="background:#222;padding:20px;border-radius:10px;margin-bottom:20px;">
        <p>💰 إجمالي النقود: {total_money}</p>
        <p>📏 النصاب: {nisab}</p>
        <p style="color:#FFD700;font-size:1.5rem;">🧮 الزكاة المستحقة: {zakat_due:.2f}</p>
    </div>
    <form method="POST">
        <input name="amount" placeholder="مبلغ الزكاة" required>
        <input name="date" type="date" required>
        <button>تسجيل</button>
    </form>
    <table>
        <tr><th>ID</th><th>المبلغ</th><th>التاريخ</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة الديون ==========
@app.route('/debts', methods=['GET', 'POST'])
def debts():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        amount = request.form['amount']
        dtype = request.form['type']
        c.execute("INSERT INTO debts (name, amount, type) VALUES (?,?,?)",
                  (name, amount, dtype))
        conn.commit()
        log_action(f"إضافة دين: {name}")
    c.execute("SELECT * FROM debts")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/bank">🏦 البنك</a>
        <a href="/zakat">🕌 الزكاة</a>
        <a href="/debts">💳 الديون</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>💳 الديون</h2>
    <form method="POST">
        <input name="name" placeholder="اسم الدين" required>
        <input name="amount" placeholder="المبلغ" required>
        <select name="type">
            <option>علينا</option>
            <option>لنا</option>
        </select>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الاسم</th><th>المبلغ</th><th>النوع</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة الميزانيات ==========
@app.route('/budgets', methods=['GET', 'POST'])
def budgets():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        amount = request.form['amount']
        c.execute("INSERT INTO budgets (name, amount) VALUES (?,?)", (name, amount))
        conn.commit()
        log_action(f"إضافة ميزانية: {name}")
    c.execute("SELECT * FROM budgets")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/bank">🏦 البنك</a>
        <a href="/zakat">🕌 الزكاة</a>
        <a href="/debts">💳 الديون</a>
        <a href="/budgets">📋 الميزانيات</a>
        <a href="/projects">📁 المشاريع</a>
        <a href="/contracts">📜 العقود</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>📋 الميزانيات</h2>
    <form method="POST">
        <input name="name" placeholder="اسم الميزانية" required>
        <input name="amount" placeholder="المبلغ" required>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الاسم</th><th>المبلغ</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة المشاريع ==========
@app.route('/projects', methods=['GET', 'POST'])
def projects():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        budget = request.form['budget']
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        status = request.form.get('status', 'نشط')
        c.execute("INSERT INTO projects (name, budget, start_date, end_date, status) VALUES (?,?,?,?,?)",
                  (name, budget, start_date, end_date, status))
        conn.commit()
        log_action(f"إضافة مشروع: {name}")
    c.execute("SELECT * FROM projects")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/budgets">📋 الميزانيات</a>
        <a href="/projects">📁 المشاريع</a>
        <a href="/contracts">📜 العقود</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>📁 المشاريع</h2>
    <form method="POST">
        <input name="name" placeholder="اسم المشروع" required>
        <input name="budget" placeholder="الميزانية" required>
        <input name="start_date" type="date" required>
        <input name="end_date" type="date" required>
        <select name="status">
            <option>نشط</option>
            <option>مكتمل</option>
            <option>ملغى</option>
        </select>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الاسم</th><th>الميزانية</th><th>البداية</th><th>النهاية</th><th>الحالة</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td><td>{r[4]}</td><td>{r[5]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة العقود ==========
@app.route('/contracts', methods=['GET', 'POST'])
def contracts():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        title = request.form['title']
        party = request.form['party']
        amount = request.form['amount']
        date = request.form['date']
        status = request.form.get('status', 'ساري')
        c.execute("INSERT INTO contracts (title, party, amount, date, status) VALUES (?,?,?,?,?)",
                  (title, party, amount, date, status))
        conn.commit()
        log_action(f"إضافة عقد: {title}")
    c.execute("SELECT * FROM contracts")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/projects">📁 المشاريع</a>
        <a href="/contracts">📜 العقود</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>📜 العقود</h2>
    <form method="POST">
        <input name="title" placeholder="عنوان العقد" required>
        <input name="party" placeholder="الطرف الآخر" required>
        <input name="amount" placeholder="المبلغ" required>
        <input name="date" type="date" required>
        <select name="status">
            <option>ساري</option>
            <option>منتهي</option>
            <option>ملغى</option>
        </select>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>العنوان</th><th>الطرف</th><th>المبلغ</th><th>التاريخ</th><th>الحالة</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td><td>{r[4]}</td><td>{r[5]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة المستخدمين ==========
@app.route('/users')
def users():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM users")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/users">👤 المستخدمون</a>
        <a href="/settings">⚙️ الإعدادات</a>
        <a href="/messages">✉️ الرسائل</a>
        <a href="/alerts">🔔 التنبيهات</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>👤 المستخدمون</h2>
    <form method="POST" action="/add_user">
        <input name="username" placeholder="اسم المستخدم" required>
        <input name="password" placeholder="كلمة المرور" required>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>المستخدم</th><th>كلمة المرور</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

@app.route('/add_user', methods=['POST'])
def add_user():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT INTO users (username, password) VALUES (?,?)",
              (request.form['username'], request.form['password']))
    conn.commit()
    conn.close()
    log_action(f"إضافة مستخدم: {request.form['username']}")
    return redirect('/users')

# ========== واجهة الإعدادات ==========
@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        for key, value in request.form.items():
            c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))
        conn.commit()
        log_action("تحديث الإعدادات")
    c.execute("SELECT * FROM settings")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/users">👤 المستخدمون</a>
        <a href="/settings">⚙️ الإعدادات</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>⚙️ الإعدادات</h2>
    <form method="POST">
        <label>اسم الشركة:</label>
        <input name="company_name" placeholder="اسم الشركة"><br>
        <label>العملة الافتراضية:</label>
        <input name="default_currency" placeholder="مثال: USD"><br>
        <label>حد التنبيه للمخزون:</label>
        <input name="low_stock_threshold" placeholder="مثال: 5"><br>
        <button>حفظ</button>
    </form>
    <table>
        <tr><th>المفتاح</th><th>القيمة</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة الرسائل ==========
@app.route('/messages', methods=['GET', 'POST'])
def messages():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        sender = session['user']
        receiver = request.form['receiver']
        subject = request.form['subject']
        body = request.form['body']
        from datetime import datetime
        date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        c.execute("INSERT INTO messages (sender, receiver, subject, body, date) VALUES (?,?,?,?,?)",
                  (sender, receiver, subject, body, date))
        conn.commit()
        log_action(f"إرسال رسالة إلى {receiver}")
    c.execute("SELECT * FROM messages ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/messages">✉️ الرسائل</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>✉️ الرسائل</h2>
    <form method="POST">
        <input name="receiver" placeholder="إلى" required>
        <input name="subject" placeholder="الموضوع" required>
        <textarea name="body" placeholder="نص الرسالة"></textarea>
        <button>إرسال</button>
    </form>
    <table>
        <tr><th>ID</th><th>من</th><th>إلى</th><th>الموضوع</th><th>التاريخ</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td><td>{r[5]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة التنبيهات ==========
@app.route('/alerts')
def alerts():
    if 'user' not in session:
        return redirect('/login')
    create_alerts()
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 50")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/alerts">🔔 التنبيهات</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>🔔 التنبيهات</h2>
    <table>
        <tr><th>ID</th><th>الرسالة</th><th>النوع</th><th>التاريخ</th></tr>
    '''
    for r in rows:
        color = "#fff"
        if r[2] == 'warning':
            color = "#ffd700"
        elif r[2] == 'danger':
            color = "#ff4a4a"
        content += f'<tr style="color:{color}"><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== التقارير المالية ==========
@app.route('/reports')
def reports():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    revenue = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM purchase_orders")
    expenses = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount > 0")
    inflow = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount < 0")
    outflow = c.fetchone()[0]
    net = revenue - expenses
    net_cash = inflow + outflow
    conn.close()
    content = f'''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/reports">📊 التقارير</a>
        <a href="/currencies">💱 العملات</a>
        <a href="/assets">🏢 الأصول</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>📊 التقارير المالية</h2>
    <table>
        <tr><th>البند</th><th>القيمة</th></tr>
        <tr><td>💰 الإيرادات</td><td>{revenue}</td></tr>
        <tr><td>📉 المصاريف</td><td>{expenses}</td></tr>
        <tr><td>📈 صافي الربح</td><td>{net}</td></tr>
        <tr><td>💵 التدفق الداخل</td><td>{inflow}</td></tr>
        <tr><td>💸 التدفق الخارج</td><td>{outflow}</td></tr>
        <tr><td>💎 صافي التدفق</td><td>{net_cash}</td></tr>
    </table>
    </div>'''
    return PAGE_STYLE + content

# ========== واجهة العملات ==========
@app.route('/currencies', methods=['GET', 'POST'])
def currencies():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        code = request.form['code']
        rate = request.form['rate']
        c.execute("INSERT INTO currencies (code, rate) VALUES (?,?)", (code, rate))
        conn.commit()
        log_action(f"إضافة عملة: {code}")
    c.execute("SELECT * FROM currencies")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/reports">📊 التقارير</a>
        <a href="/currencies">💱 العملات</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>💱 العملات</h2>
    <form method="POST">
        <input name="code" placeholder="رمز العملة (مثال: USD)" required>
        <input name="rate" placeholder="السعر" required>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الرمز</th><th>السعر</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== واجهة الأصول ==========
@app.route('/assets', methods=['GET', 'POST'])
def assets():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        value = request.form['value']
        depreciation = request.form['depreciation']
        c.execute("INSERT INTO assets (name, value, depreciation) VALUES (?,?,?)",
                  (name, value, depreciation))
        conn.commit()
        log_action(f"إضافة أصل: {name}")
    c.execute("SELECT * FROM assets")
    rows = c.fetchall()
    conn.close()
    content = '''
    <div class="nav">
        <a href="/magical">🏠 الرئيسية</a>
        <a href="/assets">🏢 الأصول</a>
        <a href="/logout">🚪 خروج</a>
    </div>
    <div class="container">
    <h2>🏢 الأصول</h2>
    <form method="POST">
        <input name="name" placeholder="اسم الأصل" required>
        <input name="value" placeholder="القيمة" required>
        <input name="depreciation" placeholder="الإهلاك" required>
        <button>إضافة</button>
    </form>
    <table>
        <tr><th>ID</th><th>الاسم</th><th>القيمة</th><th>الإهلاك</th></tr>
    '''
    for r in rows:
        content += f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>'
    content += '</table></div>'
    return PAGE_STYLE + content

# ========== تشغيل التطبيق ==========

# ========== اللوحة السحرية المطورة ==========
@app.route('/magical_v3')
def magical_v3():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    
    # إحصائيات شاملة
    c.execute("SELECT COUNT(*) FROM accounts")
    accounts = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM customers")
    customers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM suppliers")
    suppliers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM invoices")
    invoices = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM products")
    products = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM bank_moves")
    bank_moves = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM projects")
    projects = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM contracts")
    contracts = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM messages")
    messages = c.fetchone()[0]
    
    # المبالغ
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    revenue = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM purchase_orders")
    expenses = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount > 0")
    inflow = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount < 0")
    outflow = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(balance),0) FROM accounts WHERE type='أصول'")
    total_assets = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(balance),0) FROM accounts WHERE type='خصوم'")
    total_liabilities = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(stock),0) FROM products")
    total_stock = c.fetchone()[0]
    
    net = revenue - expenses
    net_cash = inflow + outflow
    equity = total_assets - total_liabilities
    
    # آخر العمليات
    c.execute("SELECT * FROM bank_moves ORDER BY id DESC LIMIT 5")
    recent_moves = c.fetchall()
    c.execute("SELECT * FROM invoices ORDER BY id DESC LIMIT 5")
    recent_invoices = c.fetchall()
    
    conn.close()
    
    # حكمة اليوم
    from datetime import datetime
    day = datetime.now().day
    wisdoms = [
        "الربح الحقيقي هو ما يبقى بعد سداد الالتزامات",
        "المحاسبة الجيدة أساس النجاح المالي",
        "الإنفاق بحكمة أفضل من الادخار ببخل",
        "الاستثمار في المعرفة يحقق أعلى عائد",
        "الزكاة تزيد المال بركة",
        "التخطيط المالي بداية الثراء",
        "راقب تدفقاتك النقدية دائماً",
        "التنويع يقلل المخاطر",
    ]
    wisdom = wisdoms[day % len(wisdoms)]
    
    # نسبة النمو
    growth = 0
    if revenue > 0 and expenses > 0:
        growth = ((revenue - expenses) / revenue) * 100
    
    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>🦅 نوح - لوحة السحر الشامل</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: Tahoma, sans-serif;
                background: #000011;
                color: #fff;
                min-height: 100vh;
                overflow-x: hidden;
                position: relative;
            }}
            /* نجوم */
            .star {{
                position: fixed;
                border-radius: 50%;
                background: #fff;
                pointer-events: none;
                animation: twinkle ease-in-out infinite;
            }}
            @keyframes twinkle {{
                0%, 100% {{ opacity: 0.3; transform: scale(1); }}
                50% {{ opacity: 1; transform: scale(1.5); }}
            }}
            .main-container {{
                position: relative;
                z-index: 2;
                max-width: 1300px;
                margin: 0 auto;
                padding: 30px 20px;
            }}
            /* الساعة */
            .clock {{
                text-align: center;
                color: #FFD700;
                font-size: 1.5rem;
                margin-bottom: 20px;
                text-shadow: 0 0 15px rgba(255,215,0,0.6);
            }}
            .header {{
                text-align: center;
                margin-bottom: 40px;
            }}
            .header h1 {{
                font-size: 3rem;
                font-weight: 900;
                background: linear-gradient(45deg, #FFD700, #FF8C00, #FFD700);
                background-size: 300% 300%;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: gradient-shift 3s ease infinite;
            }}
            @keyframes gradient-shift {{
                0% {{ background-position: 0% 50%; }}
                50% {{ background-position: 100% 50%; }}
                100% {{ background-position: 0% 50%; }}
            }}
            /* حكمة اليوم */
            .wisdom-box {{
                background: rgba(255,215,0,0.1);
                border: 1px solid rgba(255,215,0,0.3);
                border-radius: 15px;
                padding: 15px;
                text-align: center;
                margin-bottom: 30px;
                color: #FFD700;
                font-size: 1.1rem;
                animation: fade-in-out 4s ease-in-out infinite;
            }}
            @keyframes fade-in-out {{
                0%, 100% {{ opacity: 0.7; }}
                50% {{ opacity: 1; }}
            }}
            /* بطاقات الإحصائيات */
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
                gap: 15px;
                margin-bottom: 30px;
            }}
            .stat-card {{
                background: linear-gradient(145deg, rgba(30,30,70,0.9), rgba(15,15,40,0.9));
                border-radius: 20px;
                padding: 25px 15px;
                text-align: center;
                border: 1px solid rgba(255,255,255,0.15);
                transition: all 0.3s;
                cursor: pointer;
            }}
            .stat-card:hover {{
                transform: translateY(-8px);
                border-color: #00c8ff;
                box-shadow: 0 10px 30px rgba(0,200,255,0.3);
            }}
            .stat-card .icon {{
                font-size: 2.5rem;
                margin-bottom: 10px;
            }}
            .stat-card .value {{
                font-size: 2rem;
                font-weight: 900;
                color: #fff;
                text-shadow: 0 0 15px rgba(0,200,255,0.5);
            }}
            .stat-card .label {{
                color: #aaa;
                font-size: 0.85rem;
                margin-top: 5px;
            }}
            /* الملخص المالي */
            .financial-summary {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }}
            .summary-card {{
                background: linear-gradient(145deg, rgba(40,40,90,0.95), rgba(20,20,50,0.95));
                border-radius: 25px;
                padding: 30px;
                text-align: center;
                border: 1px solid rgba(255,215,0,0.3);
            }}
            .summary-card h3 {{
                color: #FFD700;
                margin-bottom: 15px;
                font-size: 1.3rem;
            }}
            .summary-card .amount {{
                font-size: 2.5rem;
                font-weight: 900;
            }}
            .positive {{ color: #4aff4a; }}
            .negative {{ color: #ff4a4a; }}
            .neutral {{ color: #FFD700; }}
            /* آخر العمليات */
            .recent-section {{
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 30px;
            }}
            .recent-box {{
                background: rgba(20,20,50,0.8);
                border-radius: 20px;
                padding: 20px;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            .recent-box h3 {{
                color: #00c8ff;
                margin-bottom: 15px;
            }}
            .recent-item {{
                padding: 10px;
                border-bottom: 1px solid rgba(255,255,255,0.05);
                font-size: 0.9rem;
            }}
            /* أزرار */
            .quick-actions {{
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                justify-content: center;
                margin-top: 20px;
            }}
            .quick-actions a {{
                background: linear-gradient(145deg, #222244, #111133);
                color: #fff;
                padding: 12px 25px;
                border-radius: 30px;
                text-decoration: none;
                font-size: 0.9rem;
                border: 1px solid rgba(255,255,255,0.2);
                transition: all 0.3s;
            }}
            .quick-actions a:hover {{
                background: #00c8ff;
                color: #000;
                transform: scale(1.1);
                box-shadow: 0 0 25px rgba(0,200,255,0.5);
            }}
            @media (max-width: 768px) {{
                .recent-section {{
                    grid-template-columns: 1fr;
                }}
            }}
        </style>
    </head>
    <body>
        <div class="main-container">
            <div class="clock" id="clock"></div>
            <div class="header">
                <h1>🦅 نوح - لوحة السحر الشامل</h1>
            </div>
            <div class="wisdom-box">💡 {wisdom}</div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon">📚</div>
                    <div class="value" data-target="{accounts}">0</div>
                    <div class="label">الحسابات</div>
                </div>
                <div class="stat-card">
                    <div class="icon">👥</div>
                    <div class="value" data-target="{customers}">0</div>
                    <div class="label">العملاء</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📦</div>
                    <div class="value" data-target="{suppliers}">0</div>
                    <div class="label">الموردون</div>
                </div>
                <div class="stat-card">
                    <div class="icon">🧾</div>
                    <div class="value" data-target="{invoices}">0</div>
                    <div class="label">الفواتير</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📦</div>
                    <div class="value" data-target="{products}">0</div>
                    <div class="label">المنتجات</div>
                </div>
                <div class="stat-card">
                    <div class="icon">🏦</div>
                    <div class="value" data-target="{bank_moves}">0</div>
                    <div class="label">حركات بنكية</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📁</div>
                    <div class="value" data-target="{projects}">0</div>
                    <div class="label">المشاريع</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📜</div>
                    <div class="value" data-target="{contracts}">0</div>
                    <div class="label">العقود</div>
                </div>
            </div>

            <div class="financial-summary">
                <div class="summary-card">
                    <h3>💰 الإيرادات</h3>
                    <div class="amount positive" id="revenue">{revenue}</div>
                </div>
                <div class="summary-card">
                    <h3>📉 المصاريف</h3>
                    <div class="amount negative" id="expenses">{expenses}</div>
                </div>
                <div class="summary-card">
                    <h3>📈 صافي الربح</h3>
                    <div class="amount neutral" id="net">{net}</div>
                </div>
                <div class="summary-card">
                    <h3>💵 التدفق النقدي</h3>
                    <div class="amount {"positive" if net_cash >= 0 else "negative"}" id="net_cash">{net_cash}</div>
                </div>
                <div class="summary-card">
                    <h3>🏢 الأصول</h3>
                    <div class="amount neutral">{total_assets}</div>
                </div>
                <div class="summary-card">
                    <h3>📊 حقوق الملكية</h3>
                    <div class="amount positive">{equity}</div>
                </div>
            </div>

            <div class="recent-section">
                <div class="recent-box">
                    <h3>🏦 آخر الحركات البنكية</h3>
                    {''.join(f'<div class="recent-item">{r[1]} - {r[2]} - {r[3]}</div>' for r in recent_moves)}
                </div>
                <div class="recent-box">
                    <h3>🧾 آخر الفواتير</h3>
                    {''.join(f'<div class="recent-item">فاتورة رقم {r[0]} - {r[2]} - {r[3]}</div>' for r in recent_invoices)}
                </div>
            </div>

            <div class="quick-actions">
                <a href="/ai/financial_analyst">🧠 المحلل المالي</a>
                <a href="/ai/forecaster">🔮 التنبؤ</a>
                <a href="/ai/risk_manager">🛡️ المخاطر</a>
                <a href="/ai/zakat_calculator">🕌 الزكاة الذكية</a>
                <a href="/ai/strategist">👑 الاستراتيجي</a>
            </div>
            <div class="quick-actions">
                <a href="/accounts">📚 الحسابات</a>
                <a href="/customers">👥 العملاء</a>
                <a href="/suppliers">📦 الموردون</a>
                <a href="/invoices">🧾 الفواتير</a>
                <a href="/products">📦 المنتجات</a>
                <a href="/bank">🏦 البنك</a>
                <a href="/zakat">🕌 الزكاة</a>
                <a href="/reports">📊 التقارير</a>
                <a href="/projects">📁 المشاريع</a>
                <a href="/contracts">📜 العقود</a>
                <a href="/messages">✉️ الرسائل</a>
                <a href="/settings">⚙️ الإعدادات</a>
                <a href="/logout">🚪 خروج</a>
            </div>
        </div>

        <script>
            // الساعة
            function updateClock() {{
                const now = new Date();
                const time = now.toLocaleTimeString('ar');
                const date = now.toLocaleDateString('ar', {{ weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }});
                document.getElementById('clock').textContent = date + ' - ' + time;
            }}
            updateClock();
            setInterval(updateClock, 1000);

            // نجوم
            for (let i = 0; i < 80; i++) {{
                const star = document.createElement('div');
                star.classList.add('star');
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.width = Math.random() * 3 + 1 + 'px';
                star.style.height = star.style.width;
                star.style.animationDuration = Math.random() * 3 + 1 + 's';
                star.style.animationDelay = Math.random() * 5 + 's';
                document.body.appendChild(star);
            }}

            // عدادات
            document.querySelectorAll('.value').forEach(el => {{
                const target = parseInt(el.getAttribute('data-target'));
                let current = 0;
                const step = Math.max(1, Math.floor(target / 40));
                const interval = setInterval(() => {{
                    current += step;
                    if (current >= target) {{
                        el.textContent = target;
                        clearInterval(interval);
                    }} else {{
                        el.textContent = current;
                    }}
                }}, 30);
            }});
        </script>
    </body>
    </html>
    '''


# ========== اللوحة السحرية المطورة ==========



# ========== العقول الخمسة للذكاء الاصطناعي ==========

# 1. عقل المحلل المالي
@app.route('/ai/financial_analyst')
def ai_financial_analyst():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    revenue = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM purchase_orders")
    expenses = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount > 0")
    inflow = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount < 0")
    outflow = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM customers")
    customers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM products")
    products = c.fetchone()[0]
    conn.close()
    
    net = revenue - expenses
    profit_margin = (net / revenue * 100) if revenue > 0 else 0
    cash_flow = inflow + outflow
    
    # تحليل ذكي
    analysis = []
    if profit_margin > 30:
        analysis.append("📈 الربحية ممتازة! استمر في استراتيجيتك الحالية.")
    elif profit_margin > 10:
        analysis.append("📊 الربحية جيدة، يمكن تحسينها بزيادة المبيعات.")
    else:
        analysis.append("⚠️ الربحية منخفضة، راجع مصاريفك.")
    
    if cash_flow < 0:
        analysis.append("🚨 التدفق النقدي سلبي! تحتاج إلى ضخ سيولة.")
    else:
        analysis.append("✅ التدفق النقدي إيجابي، وضعك المالي مستقر.")
    
    if customers < 5:
        analysis.append("👥 قاعدة العملاء صغيرة، ركز على التسويق.")
    
    if products < 5:
        analysis.append("📦 مخزون المنتجات محدود، فكر في التوسع.")
    
    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>🧠 عقل المحلل المالي</title>
        <style>
            body {{ font-family: Tahoma; background: #0a0a1a; color: #fff; padding: 30px; direction: rtl; }}
            .container {{ max-width: 900px; margin: 0 auto; background: #1a1a3e; border-radius: 20px; padding: 30px; }}
            h1 {{ color: #00c8ff; text-align: center; margin-bottom: 30px; }}
            .analysis-box {{ background: #222; border-radius: 15px; padding: 20px; margin: 15px 0; border-right: 4px solid #00c8ff; }}
            .metric {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px; }}
            .metric-card {{ background: #111; border-radius: 10px; padding: 15px; text-align: center; }}
            a {{ color: #00c8ff; text-decoration: none; margin: 10px; display: inline-block; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🧠 عقل المحلل المالي</h1>
            <div class="metric">
                <div class="metric-card">💰 الإيرادات: {revenue}</div>
                <div class="metric-card">📉 المصاريف: {expenses}</div>
                <div class="metric-card">📈 صافي الربح: {net}</div>
                <div class="metric-card">📊 هامش الربح: {profit_margin:.1f}%</div>
            </div>
            {''.join(f'<div class="analysis-box">{a}</div>' for a in analysis)}
            <a href="/magical_v3">🏠 العودة للوحة الرئيسية</a>
        </div>
    </body>
    </html>
    '''

# 2. عقل التنبؤ
@app.route('/ai/forecaster')
def ai_forecaster():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT date, SUM(amount) FROM invoices GROUP BY date ORDER BY date")
    data = c.fetchall()
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    current_revenue = c.fetchone()[0]
    conn.close()
    
    # تنبؤ بسيط
    if len(data) > 0:
        avg = current_revenue / max(len(data), 1)
        next_month = current_revenue * 1.1
        next_quarter = current_revenue * 1.3
    else:
        avg = 0
        next_month = 0
        next_quarter = 0
    
    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>🔮 عقل التنبؤ</title>
        <style>
            body {{ font-family: Tahoma; background: #0a0a1a; color: #fff; padding: 30px; direction: rtl; }}
            .container {{ max-width: 900px; margin: 0 auto; background: #1a1a3e; border-radius: 20px; padding: 30px; }}
            h1 {{ color: #FFD700; text-align: center; margin-bottom: 30px; }}
            .prediction {{ background: #222; border-radius: 15px; padding: 20px; margin: 15px 0; text-align: center; }}
            .prediction h3 {{ color: #FFD700; }}
            .prediction .value {{ font-size: 2rem; color: #fff; }}
            a {{ color: #FFD700; text-decoration: none; margin: 10px; display: inline-block; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔮 عقل التنبؤ المالي</h1>
            <div class="prediction">
                <h3>الإيراد الحالي</h3>
                <div class="value">{current_revenue}</div>
            </div>
            <div class="prediction">
                <h3>متوسط الإيراد اليومي</h3>
                <div class="value">{avg:.2f}</div>
            </div>
            <div class="prediction">
                <h3>توقع الشهر القادم</h3>
                <div class="value">{next_month:.2f}</div>
            </div>
            <div class="prediction">
                <h3>توقع الربع القادم</h3>
                <div class="value">{next_quarter:.2f}</div>
            </div>
            <a href="/magical_v3">🏠 العودة للوحة الرئيسية</a>
        </div>
    </body>
    </html>
    '''

# 3. عقل المخاطر
@app.route('/ai/risk_manager')
def ai_risk_manager():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COALESCE(SUM(amount),0) FROM debts WHERE type='علينا'")
    our_debts = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM debts WHERE type='لنا'")
    their_debts = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves")
    cash = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices WHERE paid=0")
    unpaid = c.fetchone()[0]
    conn.close()
    
    risks = []
    if our_debts > cash:
        risks.append("🚨 الديون المستحقة علينا أكبر من النقد المتاح!")
    if unpaid > 0:
        risks.append(f"⚠️ لديك فواتير غير مدفوعة بقيمة {unpaid}")
    if cash < 0:
        risks.append("🚨 الرصيد النقدي سلبي!")
    if not risks:
        risks.append("✅ لا توجد مخاطر كبيرة حالياً. وضعك المالي آمن.")
    
    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>🛡️ عقل المخاطر</title>
        <style>
            body {{ font-family: Tahoma; background: #0a0a1a; color: #fff; padding: 30px; direction: rtl; }}
            .container {{ max-width: 900px; margin: 0 auto; background: #1a1a3e; border-radius: 20px; padding: 30px; }}
            h1 {{ color: #ff4a4a; text-align: center; margin-bottom: 30px; }}
            .risk {{ background: #222; border-radius: 15px; padding: 20px; margin: 15px 0; border-right: 4px solid #ff4a4a; }}
            .safe {{ background: #222; border-radius: 15px; padding: 20px; margin: 15px 0; border-right: 4px solid #4aff4a; }}
            a {{ color: #ff4a4a; text-decoration: none; margin: 10px; display: inline-block; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🛡️ عقل المخاطر المالية</h1>
            {''.join(f'<div class="risk">{r}</div>' for r in risks)}
            <a href="/magical_v3">🏠 العودة للوحة الرئيسية</a>
        </div>
    </body>
    </html>
    '''

# 4. عقل الزكاة الذكي
@app.route('/ai/zakat_calculator')
def ai_zakat_calculator():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COALESCE(SUM(amount),0) FROM bank_moves WHERE amount > 0")
    cash = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(balance),0) FROM accounts WHERE type='أصول'")
    assets = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM debts WHERE type='لنا'")
    receivables = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM debts WHERE type='علينا'")
    payables = c.fetchone()[0]
    conn.close()
    
    total_zakatable = cash + assets + receivables - payables
    nisab = 85 * 60  # نصاب الذهب
    zakat_due = total_zakatable * 0.025 if total_zakatable >= nisab else 0
    
    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>🕌 عقل الزكاة</title>
        <style>
            body {{ font-family: Tahoma; background: #0a0a1a; color: #fff; padding: 30px; direction: rtl; }}
            .container {{ max-width: 900px; margin: 0 auto; background: #1a1a3e; border-radius: 20px; padding: 30px; }}
            h1 {{ color: #4aff4a; text-align: center; margin-bottom: 30px; }}
            .detail {{ background: #222; border-radius: 10px; padding: 15px; margin: 10px 0; display: flex; justify-content: space-between; }}
            .total {{ background: #1a3e1a; border-radius: 15px; padding: 25px; text-align: center; margin-top: 20px; }}
            .total .amount {{ font-size: 2.5rem; color: #4aff4a; }}
            a {{ color: #4aff4a; text-decoration: none; margin: 10px; display: inline-block; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🕌 عقل الزكاة الذكي</h1>
            <div class="detail"><span>النقد المتاح:</span><span>{cash}</span></div>
            <div class="detail"><span>الأصول:</span><span>{assets}</span></div>
            <div class="detail"><span>الديون لنا:</span><span>{receivables}</span></div>
            <div class="detail"><span>الديون علينا:</span><span>{payables}</span></div>
            <div class="detail"><span>النصاب:</span><span>{nisab}</span></div>
            <div class="total">
                <h3>الزكاة المستحقة</h3>
                <div class="amount">{zakat_due:.2f}</div>
            </div>
            <a href="/magical_v3">🏠 العودة للوحة الرئيسية</a>
        </div>
    </body>
    </html>
    '''

# 5. عقل الاستراتيجي
@app.route('/ai/strategist')
def ai_strategist():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COALESCE(SUM(amount),0) FROM invoices")
    revenue = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(amount),0) FROM purchase_orders")
    expenses = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM customers")
    customers = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM products")
    products = c.fetchone()[0]
    conn.close()
    
    strategies = []
    if customers < 10:
        strategies.append("👥 ركز على اكتساب عملاء جدد من خلال التسويق الرقمي.")
    if products < 10:
        strategies.append("📦 قم بتوسيع خط منتجاتك لزيادة مصادر الدخل.")
    if revenue > 0 and expenses > 0:
        ratio = expenses / revenue
        if ratio > 0.7:
            strategies.append("📉 مصاريفك مرتفعة، حاول خفض التكاليف التشغيلية.")
        else:
            strategies.append("📈 وضعك جيد، فكر في التوسع.")
    strategies.append("💡 استثمر في التكنولوجيا لتحسين الكفاءة.")
    strategies.append("🌍 فكر في التوسع الإقليمي والدولي.")
    
    return f'''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>👑 عقل الاستراتيجي</title>
        <style>
            body {{ font-family: Tahoma; background: #0a0a1a; color: #fff; padding: 30px; direction: rtl; }}
            .container {{ max-width: 900px; margin: 0 auto; background: #1a1a3e; border-radius: 20px; padding: 30px; }}
            h1 {{ color: #FFD700; text-align: center; margin-bottom: 30px; }}
            .strategy {{ background: #222; border-radius: 15px; padding: 20px; margin: 15px 0; border-right: 4px solid #FFD700; }}
            a {{ color: #FFD700; text-decoration: none; margin: 10px; display: inline-block; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>👑 عقل الاستراتيجي</h1>
            {''.join(f'<div class="strategy">{s}</div>' for s in strategies)}
            <a href="/magical_v3">🏠 العودة للوحة الرئيسية</a>
        </div>
    </body>
    </html>
    '''


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
